
import Layout from '../components/Layout'

import Router from 'next/router'



const handleSubmit = (e) => {

  e.preventDefault() // หยุดการทำงาน Submit

  const name = e.target.name.value

  Router.push({

    pathname: '/hello',

    query: { name: name }

  })

}



const Index = () => (

  <Layout>

    <h1>Home page</h1>
    <p>What is you name</p>

    <form onSubmit={(e) => handleSubmit(e)}>

      <span>name: </span>

      <input type="text" name="name"/>

      <button type="submit">Go</button>

    </form>

  </Layout>

)



export default Index