
import Layout from '../components/Layout'



const Hello = (props) => (

  <Layout>

    <h1>Hi {props.url.query.name}</h1>
    <p>nice to meet you!</p>
    
  </Layout>

)



export default Hello